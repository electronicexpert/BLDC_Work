/*
 * Kalman_Loop.h
 *
 *  Created on: Aug 11, 2024
 *      Author: joachim
 */

#ifndef INC_KALMAN_LOOP_H_
#define INC_KALMAN_LOOP_H_

class Kal_Loop {
public:
	Kal_Loop();
	virtual ~Kal_Loop();
	void Kalman_Loop(void);

};




#endif /* INC_KALMAN_LOOP_H_ */
