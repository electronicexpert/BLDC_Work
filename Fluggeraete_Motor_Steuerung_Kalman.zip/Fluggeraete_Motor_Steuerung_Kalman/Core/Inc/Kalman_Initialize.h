/*
 * Kalman_Initialize.h
 *
 *  Created on: Aug 11, 2024
 *      Author: joachim
 */

#ifndef INC_KALMAN_INITIALIZE_H_
#define INC_KALMAN_INITIALIZE_H_


class Kal_Init {
public:
	Kal_Init();
	virtual ~Kal_Init();
	void Kalman_Initialize(void);

};


#endif /* INC_KALMAN_INITIALIZE_H_ */
